package uedit.domain;

import uedit.domain.wenjian;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public class wenjian {
	private Long id;
	private String content;
	
	public wenjian(String content) {
		this.content = content;
		}
	public wenjian() {}
}
