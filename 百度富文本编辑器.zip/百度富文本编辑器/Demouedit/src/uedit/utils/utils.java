package uedit.utils;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.sql.DataSource;

import com.alibaba.druid.pool.DruidDataSourceFactory;

public class utils {
	private static DataSource datasource;
	static{
		Properties pro=new Properties();
		ClassLoader cla=Thread.currentThread().getContextClassLoader();
		InputStream in=cla.getResourceAsStream("db.properties");
		try {
			pro.load(in);
			Class.forName(pro.getProperty("driverClassName"));
			datasource=DruidDataSourceFactory.createDataSource(pro);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static Connection conn() {
		try {
			return datasource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("数据库连接异常");
		}
	}
	public static void close(Connection conn,Statement st,ResultSet re) {
		 try {
			   if(re!=null)
					re.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
			finally {
					try {
						if(st!=null)
							st.close();
					} catch (Exception e3) {
						// TODO: handle exception
						e3.printStackTrace();
					}finally {
						try {
							if(conn!=null)
								conn.close();
						} catch (Exception e4) {
							// TODO: handle exception
							e4.printStackTrace();
						}
					}
			}
	}
}
