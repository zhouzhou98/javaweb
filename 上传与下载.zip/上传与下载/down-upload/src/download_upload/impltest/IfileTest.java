package download_upload.impltest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import download_upload.domian.file;
import download_upload.impl.fileimpl;
import download_upload.impl.filedao.Ifile;

public class IfileTest {

	@Test
	public void testInsert() {
		file fud=new file("1","1","1","1","1","1");
		Ifile fdao=new fileimpl();
		fdao.insert(fud);
	}

	@Test
	public void testList() {
		Ifile fdao=new fileimpl();
		List list=fdao.list();
		for (Object lie : list) {
			System.out.println(lie);
		}
	}

	@Test
	public void testSelect() {
		Ifile fdao=new fileimpl();
		System.out.println(fdao.select(1L));
	}

}
