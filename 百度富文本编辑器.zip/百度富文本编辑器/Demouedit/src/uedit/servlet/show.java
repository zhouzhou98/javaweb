package uedit.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import uedit.impl.editimpl;
import uedit.impl.dao.Iedit;

@WebServlet("/show")
public class show extends HttpServlet{
   private Iedit edit;
   @Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
	    edit=new editimpl();
	}
   @Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");
		List list=edit.list();
	
		req.setAttribute("list", list);
		req.getRequestDispatcher("/putsh.jsp").forward(req, resp);
	}
}
