package download_upload.domian;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor

public class file {
	private Long id;
	private String uuidname;
	private String filename;
	private String savepath;
	private String uploadtime;
	private String description;
	private String username;
	public file(){}
	
	public file(String uuidname, String filename, String savepath, String uploadtime, String description,
			String username) {
		super();
		this.uuidname = uuidname;
		this.filename = filename;
		this.savepath = savepath;
		this.uploadtime = uploadtime;
		this.description = description;
		this.username = username;
	}
	
}
