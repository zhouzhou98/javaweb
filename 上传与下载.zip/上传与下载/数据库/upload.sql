/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : upload

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2018-10-17 18:33:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `baocun`
-- ----------------------------
DROP TABLE IF EXISTS `baocun`;
CREATE TABLE `baocun` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuidname` varchar(100) DEFAULT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `savepath` varchar(100) DEFAULT NULL,
  `uploadtime` varchar(100) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of baocun
-- ----------------------------
INSERT INTO `baocun` VALUES ('1', '1', '1', '1', '1', '1', '1');
INSERT INTO `baocun` VALUES ('2', '1', '1', '1', '1', '1', '1');
INSERT INTO `baocun` VALUES ('3', 'd6606735-2bdb-46d0-aa45-a52630652123_11.txt', '11.txt', 'E:\\Java\\workforce\\down-upload\\webapp\\WEB_INF\\upload/2/10', '2018-10-16 21:37:52', '2', '1');
INSERT INTO `baocun` VALUES ('4', 'a18c8615-5483-4585-9733-67dce6cb0c0f_11.txt', '11.txt', 'E:\\Java\\workforce\\down-upload\\webapp\\wenjian\\upload/2/10', '2018-10-16 21:37:52', 'fsdf', '18826354908');
INSERT INTO `baocun` VALUES ('5', 'bf10dd65-5931-4b01-b242-8c9bc39bbe4e_11.txt', '11.txt', 'E:\\Java\\workforce\\down-upload\\webapp\\wenjian\\upload/2/10', '2018-10-16 21:37:52', 'fasd', '18826354908');
