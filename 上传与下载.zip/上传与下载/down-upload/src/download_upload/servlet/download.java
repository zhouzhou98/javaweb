package download_upload.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import download_upload.impl.fileimpl;
import download_upload.impl.filedao.Ifile;

@WebServlet("/listfile")
public class download extends HttpServlet{
	private Ifile file;
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		file=new fileimpl();
	}
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		List list=file.list();
		
		req.setAttribute("list", list);
	    req.getRequestDispatcher("/list.jsp").forward(req, resp);
	}
}
