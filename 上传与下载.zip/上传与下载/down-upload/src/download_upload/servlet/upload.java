package download_upload.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.servlet.ServletFileUpload;

import download_upload.domian.file;
import download_upload.impl.fileimpl;
import download_upload.impl.filedao.Ifile;
import net.sf.json.util.WebUtils;
@WebServlet("/upload")
public class upload extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		if (!ServletFileUpload.isMultipartContent(req)) {
			req.setAttribute("message", "不是请求的信息表单，请确认表单属性是否正确");
			req.getRequestDispatcher("/message.jsp").forward(req,resp);
			return;
		}
		
		try {
			//调用工具类，获得上传文件信息
			file fud=webutils.doFileUpload(req);
			Ifile wenjian=new fileimpl();
			wenjian.insert(fud);
			req.setAttribute("message", "上传文件成功");
			req.getRequestDispatcher("/message.jsp").forward(req,resp);
		
		
		} catch (Exception e) {
			req.setAttribute("message", "对不起，您上传的文件大小超过了大小的限制");
			req.getRequestDispatcher("/message.jsp").forward(req,resp);
		}
 


	}
}
