/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : editor

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2018-10-20 21:25:37
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `edit`
-- ----------------------------
DROP TABLE IF EXISTS `edit`;
CREATE TABLE `edit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of edit
-- ----------------------------
INSERT INTO `edit` VALUES ('1', '1');
INSERT INTO `edit` VALUES ('2', '1');
INSERT INTO `edit` VALUES ('3', '1');
INSERT INTO `edit` VALUES ('4', '1');
INSERT INTO `edit` VALUES ('5', '1');
INSERT INTO `edit` VALUES ('6', '<p>');
INSERT INTO `edit` VALUES ('7', '\r\n<p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540028604073016780.jpg\" title=\"1540028604073016780.jpg\" alt=\"微信图片_20180808181855.jpg\"/></p>\r\n');
INSERT INTO `edit` VALUES ('8', '<p><img src=\'1.png\'/></p>');
INSERT INTO `edit` VALUES ('9', '<p><img src=\'1.png\'/></p>');
INSERT INTO `edit` VALUES ('10', '22');
INSERT INTO `edit` VALUES ('11', '22');
INSERT INTO `edit` VALUES ('12', '<p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540029740131025730.jpg\" title=\"1540029740131025730.jpg\" alt=\"微信图片_20180808181918.jpg\"/></p>');
INSERT INTO `edit` VALUES ('13', '<p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540029847627036123.jpg\" title=\"1540029847627036123.jpg\"/></p><p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540029847646003562.jpg\" title=\"1540029847646003562.jpg\"/></p><p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540029847713056650.jpg\" title=\"1540029847713056650.jpg\"/></p><p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540029847760038252.jpg\" title=\"1540029847760038252.jpg\"/></p><p><br/></p>');
INSERT INTO `edit` VALUES ('14', '<p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540031623049040541.jpg\" title=\"1540031623049040541.jpg\" alt=\"微信图片_20180808181918.jpg\"/></p>');
INSERT INTO `edit` VALUES ('15', '<p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540034015996069176.jpg\" title=\"1540034015996069176.jpg\"/></p><p><img src=\"/Demouedit/utf8-jsp/jsp/upload/image/20181020/1540034015996048296.jpg\" title=\"1540034015996048296.jpg\"/></p><p><br/></p>');
INSERT INTO `edit` VALUES ('16', '<p><img src=\"/Demouedit/../utf8-jsp/jsp/upload/image/20181020/1540035090835037410.jpg\" title=\"1540035090835037410.jpg\" alt=\"微信图片_20180808181913.jpg\"/></p>');
INSERT INTO `edit` VALUES ('17', '<p><img src=\"/Demouedit/../utf8-jsp/jsp/upload/image/20181020/1540035177191091541.jpg\" title=\"1540035177191091541.jpg\"/></p><p><img src=\"/Demouedit/../utf8-jsp/jsp/upload/image/20181020/1540035177250005531.jpg\" title=\"1540035177250005531.jpg\"/></p><p><img src=\"/Demouedit/../utf8-jsp/jsp/upload/image/20181020/1540035194010030499.jpg\" title=\"1540035194010030499.jpg\" alt=\"微信图片_20180819002120.jpg\"/></p>');
INSERT INTO `edit` VALUES ('18', '<p><img src=\"Demouedit/WebContent/utf8-jsp/jsp/upload/image/20181020/1540035656258088304.jpg\" title=\"1540035656258088304.jpg\" alt=\"微信图片_20180808181855.jpg\"/></p>');
INSERT INTO `edit` VALUES ('19', '<p><img src=\"/../utf8-jsp/jsp/upload/image/20181020/1540035942301016667.jpg\" title=\"1540035942301016667.jpg\" alt=\"微信图片_20180808181855.jpg\"/></p>');
INSERT INTO `edit` VALUES ('20', '<p><img src=\"/../utf8-jsp/jsp/upload/image/20181020/1540037491704031102.jpg\" title=\"1540037491704031102.jpg\" alt=\"微信图片_20180819002120.jpg\"/></p>');
INSERT INTO `edit` VALUES ('21', '<p><img src=\"/../utf8-jsp/jsp/upload/image/20181020/1540039304576085459.jpg\" title=\"1540039304576085459.jpg\" alt=\"微信图片_20180808181913.jpg\"/></p>');
INSERT INTO `edit` VALUES ('22', '<p><video class=\"edui-upload-video  vjs-default-skin video-js\" controls=\"\" preload=\"none\" width=\"420\" height=\"280\" src=\"utf8-jsp/../utf8-jsp/jsp/upload/video/20181020/1540039344484068705.avi\" data-setup=\"{}\"></video><img src=\"/../utf8-jsp/jsp/upload/image/20181020/1540039304576085459.jpg\" title=\"1540039304576085459.jpg\" alt=\"微信图片_20180808181913.jpg\"/></p>');
INSERT INTO `edit` VALUES ('23', '<p></p>');
INSERT INTO `edit` VALUES ('24', '<p><img width=\"530\" height=\"340\" src=\"http://api.map.baidu.com/staticimage?center=116.404,39.915&zoom=10&width=530&height=340&markers=116.544279,40.028244\"/></p><p style=\"display:none;\"><br/></p>');
INSERT INTO `edit` VALUES ('25', '<p><video class=\"edui-upload-video  vjs-default-skin video-js\" controls=\"\" preload=\"none\" width=\"420\" height=\"280\" src=\"utf8-jsp/../utf8-jsp/jsp/upload/video/20181020/1540041235040053164.avi\" data-setup=\"{}\"></video></p>');
INSERT INTO `edit` VALUES ('26', '<p><video class=\"edui-upload-video  vjs-default-skin video-js\" controls=\"\" preload=\"none\" width=\"420\" height=\"280\" src=\"/../utf8-jsp/jsp/upload/video/20181020/1540041545654020675.avi\" data-setup=\"{}\"></video></p>');
INSERT INTO `edit` VALUES ('27', '<p><video class=\"edui-upload-video  vjs-default-skin video-js\" controls=\"\" preload=\"none\" width=\"420\" height=\"280\" src=\"/../utf8-jsp/jsp/upload/video/20181020/1540041694761049246.avi\" data-setup=\"{}\"></video></p>');
