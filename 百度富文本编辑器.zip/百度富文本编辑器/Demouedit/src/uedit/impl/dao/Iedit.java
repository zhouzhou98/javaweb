package uedit.impl.dao;

import java.util.List;

import uedit.domain.wenjian;

public interface Iedit {
	public void insertdata(wenjian wen);
	public List<wenjian>list();
}
