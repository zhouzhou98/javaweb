package uedit.impl;

import java.util.List;

import uedit.javabean.javabeanlist;
import uedit.template.template;
import uedit.domain.wenjian;
import uedit.impl.dao.Iedit;

public class editimpl implements Iedit{

	@Override
	public void insertdata(wenjian wen) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO edit(content)VALUES(?)";
	    template.DMLoperator(sql, wen.getContent());
	}

	@Override
	public List<wenjian> list() {
		// TODO Auto-generated method stub
		String sql="SELECT *FROM edit";
		return template.DQLoperator(sql, new javabeanlist<>(wenjian.class));
	}

}
