package download_upload.javabean;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.sql.ResultSet;

public class javabean<T> implements type<T>{
	private  Class<T>classtype;
    public javabean(Class<T>classtype) {
		// TODO Auto-generated constructor stub
		this.classtype=classtype;
	}
	@Override
	public T hanlder(ResultSet rs) throws Exception {
		// TODO Auto-generated method stub
		if(rs.next())
        {
               T obj=classtype.newInstance();
               BeanInfo beanInfo=Introspector.getBeanInfo(classtype,Object.class);
               PropertyDescriptor[] pro=beanInfo.getPropertyDescriptors();
               for(PropertyDescriptor ps:pro)
               {
                String name=ps.getName();
                Object value=rs.getObject(name);
                ps.getWriteMethod().invoke(obj, value);
               }
               return obj;
        }
		return null;
	}

}
