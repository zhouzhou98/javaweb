package wangedit.servlet;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
@WebServlet("/upload")
public class wangedit extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/json;charset=UTF-8");
		JSONObject json = new JSONObject();
		PrintWriter out = resp.getWriter();
		String path = this.getClass().getClassLoader().getResource("/").getPath();
		int index = path.indexOf("wangeditor");
		path = path.substring(0, index + "wangeditor".length()) + "/resources/upload/";
		path = "E:/apache-tomcat-9.0.6/webapps/img";
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload sfu = new ServletFileUpload(factory);
		sfu.setHeaderEncoding("UTF-8"); // 处理中文问题
		sfu.setSizeMax(10* 1024 * 1024); // 限制文件大小
		String fileName = "";
		
		try {
			List<FileItem> fileItems = sfu.parseRequest(req);
			JSONArray arr = new JSONArray();
			for (FileItem item : fileItems) {
				
				fileName = UUID.randomUUID().toString() + item.getName();
				item.write(new File(path + "/" + fileName));
				
				InetAddress address = InetAddress.getLocalHost();// 获取的是本地的IP地址
				String hostAddress = address.getHostAddress();
				String imgUrl ="../img/"+fileName;
				arr.add(imgUrl);
				
				}
			json.put("errno", 0);
			json.put("data", arr);
			System.out.println(arr.size());
			out.print(json.toString());
			out.flush();
			out.close();
			} catch (Exception e) {
				e.printStackTrace();
				json.put("errno","200");
		        json.put("msg","服务器异常");
		        out.print(json.toString());
			}
		// 获取图片url地址
		
		
	}
}
