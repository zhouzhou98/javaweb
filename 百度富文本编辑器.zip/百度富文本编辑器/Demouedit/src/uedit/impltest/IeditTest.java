package uedit.impltest;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import uedit.domain.wenjian;
import uedit.impl.editimpl;
import uedit.impl.dao.Iedit;



public class IeditTest {

	@Test
	public void testInsertdata() {
		wenjian wen=new wenjian("<p><img src='1.png'/></p>");
		Iedit con=new editimpl();
		con.insertdata(wen);
	}

	@Test
	public void testList() {
		Iedit con=new editimpl();
		List list=con.list();
		for (Object li : list) {
			System.out.println(li);
		}
	}

}
