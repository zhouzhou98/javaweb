package uedit.javabean;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class javabeanlist<T>implements type<List<T>> {

	private Class<T>classtype;
	public javabeanlist(Class<T>classtype) {
		this.classtype=classtype;
	}
	@Override
	public List<T> hanlder(ResultSet rs) throws Exception {
		// TODO Auto-generated method stub
		List<T>list=new ArrayList<>();
        while(rs.next())
        {
               T obj=classtype.newInstance();
               BeanInfo beanInfo=Introspector.getBeanInfo(classtype,Object.class);
               PropertyDescriptor[] pro=beanInfo.getPropertyDescriptors();
               for(PropertyDescriptor ps:pro)
               {
                   String name=ps.getName();
                   Object value=rs.getObject(name);
                   ps.getWriteMethod().invoke(obj, value);
               }
               list.add(obj) ;
        }
        return list;
	}
}
