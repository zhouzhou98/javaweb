package download_upload.template;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import download_upload.javabean.type;
import download_upload.utils.utils;

public class template {
	public static int DMLoperator(String sql,Object...param) {
		Connection conn=utils.conn();
		PreparedStatement ps=null;
		try {
			ps=conn.prepareStatement(sql);
			for(int i=0;i<param.length;i++) {
				ps.setObject(i+1,param[i]);
			}
			return ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			utils.close(conn,ps,null);
		}
		return 0;
	}
	public static <T>T  DQLoperator(String sql,type<T> type,Object...para){
		Connection conn=utils.conn();
		PreparedStatement ps=null;
		ResultSet re=null;
		try {
			ps=conn.prepareStatement(sql);
			for(int i=0;i<para.length;i++) {
			ps.setObject(i+1, para[i]);
			}
			re=ps.executeQuery();
			return type.hanlder(re);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			utils.close(conn, ps, re);
		}
		return null;
	}
}
