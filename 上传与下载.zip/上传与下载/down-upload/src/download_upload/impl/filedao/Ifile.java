package download_upload.impl.filedao;

import java.util.List;

import download_upload.domian.file;

public interface Ifile {
	public void insert(file fud);//上传文件
	 
	public List<file> list();//查询文件
 
	public file select(Long id);//通过id获得文件的全部信息


}
