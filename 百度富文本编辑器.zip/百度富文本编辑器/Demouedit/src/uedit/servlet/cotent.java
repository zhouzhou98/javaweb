package uedit.servlet;

import java.io.IOException;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import uedit.domain.wenjian;
import uedit.impl.editimpl;
import uedit.impl.dao.Iedit;
@WebServlet("/wenjian")
public class cotent extends HttpServlet{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    req.setCharacterEncoding("UTF-8");
	    resp.setContentType("text/html;charser=UTF-8");
	    String content = req.getParameter("editor");
	    System.out.println(content);
	    Iedit con=new editimpl();
	    wenjian wen=new wenjian(content);
	   
	    con.insertdata(wen);
	 }
}
