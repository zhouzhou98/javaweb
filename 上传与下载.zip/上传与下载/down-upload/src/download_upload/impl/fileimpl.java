package download_upload.impl;

import java.util.List;

import download_upload.javabean.javabean;
import download_upload.javabean.javabeanlist;
import download_upload.domian.file;
import download_upload.impl.filedao.Ifile;
import download_upload.template.template;

public class fileimpl implements Ifile{

	@Override
	public void insert(file fud) {
		// TODO Auto-generated method stub
		String sql="INSERT INTO baocun (uuidname,filename,savepath,uploadtime,description,username)VALUES(?,?,?,?,?,?)";
		template.DMLoperator(sql, fud.getUuidname(),fud.getFilename(),fud.getSavepath(),fud.getUploadtime(),fud.getDescription(),fud.getUsername());
	}

	@Override
	public List<file> list() {
		// TODO Auto-generated method stub
		String sql="SELECT *FROM baocun";
		return template.DQLoperator(sql, new javabeanlist<>(file.class));
	}

	@Override
	public file select(Long id) {
		// TODO Auto-generated method stub
		String sql="SELECT *FROM baocun where id=?";
		return  template.DQLoperator(sql, new javabean<>(file.class),id);
	}

}
