package download_upload.javabean;

import java.sql.ResultSet;

public interface type <T>{
	T hanlder(ResultSet rs)throws Exception;
}
